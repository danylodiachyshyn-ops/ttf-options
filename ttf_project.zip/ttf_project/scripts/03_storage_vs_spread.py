# %% STEP 3: needs data/external/agsi_eu.csv (download from agsi.gie.eu first)
# TODO 1: implement storage.load_storage_csv()
# TODO 2: fill % on 1 Nov of each year 2018..2025 (check the series really starts that early)
# TODO 3: scatter: storage on 1 Nov (x) vs spread on 1 Nov (y), one point per winter, label the years
# TODO 4: fit linear, then 1/storage and log(storage); compare R^2 and look at residuals
# TODO 5: does storage on 1 Nov predict (spread 15 Feb - spread 1 Nov)? Note: n is tiny. Say so.
# TODO 6: show 2022 with and without. Express the spread as % of the Q3 price as well.
# TODO 7: where does today (storage ~75%, spread ~24 EUR/MWh) sit on the plot?
