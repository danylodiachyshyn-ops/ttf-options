# %% STEP 1: one winter, build the spread. You write the code.
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import matplotlib.pyplot as plt
from ttf.load import load_winters, Q1, Q3
from ttf.units import usd_mmbtu_to_eur_mwh
from ttf.spread import q_average, spread_eur_mwh

w = load_winters()["W2526"]

# TODO 1: convert the six contract columns to EUR/MWh using the same day's EURUSD
# TODO 2: Q1 and Q3 averages (see the design question in spread.py)
# TODO 3: plot Q1, Q3 and the spread; look at 30 Dec, 29 Jan, 26 Feb
# TODO 4: write down what 'Q1' will mean in your analysis, and why

# %% STEP 2: all eight winters
# TODO 5: loop over winters; for each, read the spread on ~1 Nov and ~15 Feb (what if the exact day is a holiday?)
# TODO 6: put the results in a small DataFrame: winter, spread_1nov, spread_15feb
