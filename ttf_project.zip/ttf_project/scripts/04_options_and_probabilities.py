# %% STEP 4: implied vol and probabilities from the chains
# TODO 1: implement black76 and implied_vol in optionsmath.py; make tests/test_checks.py pass
# TODO 2: implied vol for every strike of OPT_Jan27 (use calls for K>=F, puts for K<F: why?)
# TODO 3: plot the smile; compare the at-the-money vol with 68.29 (Bloomberg, Jan-27, strike 31)
# TODO 4: use r from Bloomberg (3.99%) and then the parity-implied rate (~2.5%): how much does the vol change?
# TODO 5: P(F_T > K) for a few K from the smile; compare with a lognormal using the ATM vol
# TODO 6: realized vs implied: the HVT numbers (10d 73.8, 30d 54.0, 90d 54.3) vs 68.3 implied
# Averaging caveat: TMR futures settle on an AVERAGE; Black-76 is an approximation. Say so in the write-up.
