# %% Data check: runs as is. Read the output before you build anything.
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

import pandas as pd
from ttf.load import load_winters, load_contract_history, load_chain, load_current

winters = load_winters()
for name, df in winters.items():
    print(name, df.index.min().date(), df.index.max().date(), len(df), "rows")
    print("   last valid date per column:", {c: df[c].last_valid_index().date() for c in df.columns})

# %% Live contracts and the TMRU7 problem
hist = load_contract_history()
print(sorted(hist))                    # TMRU7 is missing on purpose (duplicate sheet)
print(hist["TMRF7"].tail(3))

# %% Options chain
F, chain = load_chain("OPT_Jan27")
print("underlying", F)
print(chain.dropna().head())

# %% Today's six prices (USD/MMBtu) and EURUSD
print(load_current())
