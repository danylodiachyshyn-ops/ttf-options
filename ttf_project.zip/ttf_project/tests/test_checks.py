"""Run with: pytest -q   (from the project root). Tests unlock as you implement each piece."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
import pytest
from ttf.load import load_winters, load_contract_history, load_chain, load_current


# ---- loaders (should pass now) ----
def test_eight_winters_six_contracts():
    w = load_winters()
    assert len(w) == 8
    for df in w.values():
        assert list(df.columns)[:6] == ["Jan", "Feb", "Mar", "Jul", "Aug", "Sep"]
        assert df["EURUSD"].notna().mean() > 0.95


def test_contracts_expire_in_order():
    w = load_winters()["W2526"]
    assert w["Jan"].last_valid_index() < w["Feb"].last_valid_index() < w["Mar"].last_valid_index()


def test_tmru7_duplicate_is_skipped():
    with pytest.warns(UserWarning):
        h = load_contract_history()
    assert "TMRU7" not in h and "TMRQ7" in h


def test_chain_loads():
    F, chain = load_chain("OPT_Jan27")
    assert F == pytest.approx(31.074)
    assert chain.loc[31, "call"] == pytest.approx(3.376)


# ---- your code ----
def test_unit_conversion():
    from ttf.units import usd_mmbtu_to_eur_mwh
    assert usd_mmbtu_to_eur_mwh(31.074, 1.1206) == pytest.approx(94.61, abs=0.05)


def test_black76_reference():
    from ttf.optionsmath import black76
    assert black76(31.074, 31, 58 / 365, 0.0399, 0.6829, "c") == pytest.approx(3.3759, abs=0.001)


def test_implied_vol_recovers_bloomberg():
    from ttf.optionsmath import implied_vol
    assert implied_vol(3.376, 31.074, 31, 58 / 365, 0.0399, "c") == pytest.approx(0.6829, abs=0.002)


def test_put_gives_same_vol_as_call():
    from ttf.optionsmath import implied_vol
    # parity-consistent market: put at strike 31 settled at 3.302
    v_call = implied_vol(3.376, 31.074, 31, 58 / 365, 0.0399, "c")
    v_put = implied_vol(3.302, 31.074, 31, 58 / 365, 0.0399, "p")
    assert v_put == pytest.approx(v_call, abs=0.01)


def test_spread_today_matches_manual_check():
    """Today's spread from the six BDP prices, worked out earlier: about 24.0 EUR/MWh."""
    from ttf.units import usd_mmbtu_to_eur_mwh
    p = load_current()
    q1 = (p["TMRF7"] + p["TMRG7"] + p["TMRH7"]) / 3
    q3 = (p["TMRN7"] + p["TMRQ7"] + p["TMRU7"]) / 3
    s = usd_mmbtu_to_eur_mwh(q1 - q3, 1.1206)
    assert s == pytest.approx(24.0, abs=0.1)
