# TTF calendar spread: Q1-27 (Jan/Feb/Mar) minus Q3-27 (Jul/Aug/Sep)

Question set (from the pitch):
1. Is the move already priced in?  2. Does the spread really depend on storage?  3. What do the options imply?

## Set up in PyCharm (5 min)
1. Open this folder as a project. Create a venv, then `pip install -r requirements.txt`.
2. Right-click `src` > Mark Directory as > Sources Root.
3. Run `scripts/01_first_look.py` (cell by cell, `# %%` markers). Read the output.
4. Run `pytest -q`. Four loader tests pass; five fail until you write the code. Make them pass one by one.

## Order of work
| Step | File | What you do |
|---|---|---|
| 0 | `units.py` | USD/MMBtu to EUR/MWh (1 MWh = 3.412 MMBtu) |
| 1 | `spread.py`, `scripts/02_...` | Q1/Q3 averages, daily spread, one winter then all eight |
| 2 | `storage.py`, `scripts/03_...` | AGSI+ storage, scatter, linear vs convex fit |
| 3 | `optionsmath.py`, `scripts/04_...` | Black-76, implied vol, smile, probabilities, implied vs realized |
| 4 | write-up | 3-4 figures + limits section (2-3 pages, same format as the one-pager) |

## Data facts you must keep in mind
- Prices are USD/MMBtu (ICE Futures Europe monthly "1st Line M" futures, cash-settled on an AVERAGE of daily
  TFM settlements). Spreads in the pitch are in EUR/MWh, so convert (same-day EURUSD) before comparing.
- 8 winters: 2018/19 .. 2025/26. 2022 (W2122/W2223) is a crisis outlier. Run with and without it.
- Jan/Feb/Mar contracts expire ~30 Dec / ~28 Jan / ~26 Feb, so "Q1" changes composition during the winter.
- `TMRU7` sheet in `ttf_vol_history_pull.xlsx` is a duplicate of `TMRQ7`: loader skips it. Re-export it.
- Options: only Jan-27 and Jul-27 chains so far. Feb/Mar/Aug/Sep are in `ttf_options_chain_2.xlsx`
  (copy it into `data/raw/` once loaded, then `load_chain(sheet, path=RAW / 'ttf_options_chain_2.xlsx')`).
- Snapshot time of the chain: about 20:15 on 2 Nov 2026 (confirm). Settlement prices only, no bid/ask.
- Bloomberg uses rate 3.99% (Jan-27) .. 4.07% (later); put-call parity suggests ~2.5% (maybe the options are
  priced differently). Test how much it matters.
- Bloomberg's "Implied Vol" history column in HVT is almost flat (68.3-68.5 for months): do not use it as a series.
- Realized vol on 2 Nov (TMRF7): 10d 73.8, 30d 54.0, 90d 54.3. Bloomberg implied (strike 31): 68.29.
- COT (ICE Endex MiFID, 23 Oct): funds net long ~+207m and rising; banks net short. A risk check, not a signal.

## Honest limits to state in the paper
About 8 winters, one extreme year, overlapping daily observations (not independent), averaging in the contract
settlement, settlement-only option prices.
