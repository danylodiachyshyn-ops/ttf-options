"""Loaders for the three Bloomberg workbooks. Plumbing only: complete and tested.

Units: all prices are USD/MMBtu as exported (ICE Futures Europe monthly TMR contracts).
Convert to EUR/MWh yourself in units.py.
"""
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
from openpyxl import load_workbook

RAW = Path(__file__).resolve().parents[2] / "data" / "raw"

MONTH_BY_LETTER = {"F": "Jan", "G": "Feb", "H": "Mar", "N": "Jul", "Q": "Aug", "U": "Sep"}
Q1 = ["Jan", "Feb", "Mar"]
Q3 = ["Jul", "Aug", "Sep"]


def _num(x):
    return float(x) if isinstance(x, (int, float)) and not isinstance(x, bool) else np.nan


def load_winters(path=RAW / "ttf_bloomberg_pull.xlsx") -> dict:
    """{'W2526': DataFrame} indexed by date, columns Jan, Feb, Mar, Jul, Aug, Sep, EURUSD.

    Winter 'W2526' = Oct 2025 .. Mar 2026, contracts of the SECOND year (Q1-26, Q3-26).
    NaN after a contract expires (Jan ends ~30 Dec, Feb ~28 Jan, Mar ~26 Feb).
    """
    wb = load_workbook(path, data_only=True, read_only=True)
    out = {}
    for ws in wb.worksheets:
        if not (ws.title.startswith("W") and ws.title[1:].isdigit()):
            continue
        rows = list(ws.iter_rows(values_only=True))
        header = rows[0]
        series = {}
        for i in range(0, 14, 2):
            name = header[i]
            if not name:
                continue
            if "EURUSD" in name:
                label = "EURUSD"
            else:
                label = MONTH_BY_LETTER[name[3]]  # TMR + month letter + year
            s = {pd.Timestamp(r[i]): _num(r[i + 1]) for r in rows[1:] if r[i] is not None}
            series[label] = pd.Series(s).sort_index()
        df = pd.DataFrame(series).sort_index()
        out[ws.title] = df[Q1 + Q3 + ["EURUSD"]]
    return out


def load_contract_history(path=RAW / "ttf_vol_history_pull.xlsx") -> dict:
    """{'TMRF7': DataFrame(settle, vol10, vol30, vol90)} for the six live contracts + 'EURUSD'.

    Known problem: the TMRU7 sheet in the first export is a copy of TMRQ7 (cell A1 says TMRQ7).
    It is skipped with a warning until the file is re-exported.
    """
    wb = load_workbook(path, data_only=True, read_only=True)
    out = {}
    for ws in wb.worksheets:
        if ws.title == "README":
            continue
        rows = list(ws.iter_rows(values_only=True))
        a1 = rows[0][0] or ""
        if ws.title != "EURUSD" and a1.split()[0] != ws.title:
            warnings.warn(f"sheet {ws.title}: cell A1 says {a1!r}; skipped (duplicate data)")
            continue
        recs = [
            (pd.Timestamp(r[0]), _num(r[1]), _num(r[2]), _num(r[3]), _num(r[4]))
            for r in rows[2:]
            if r[0] is not None
        ]
        df = pd.DataFrame(recs, columns=["date", "settle", "vol10", "vol30", "vol90"]).set_index("date")
        if ws.title == "EURUSD":
            df = df[["settle"]].rename(columns={"settle": "EURUSD"})
        out[ws.title] = df.sort_index()
    return out


def load_chain(sheet: str, path=RAW / "ttf_options_chain.xlsx"):
    """Return (underlying_price, DataFrame[strike, call, put]) for sheets like 'OPT_Jan27'.

    Prices are settlement prices in USD/MMBtu. Non-existent strikes are NaN.
    """
    wb = load_workbook(path, data_only=True, read_only=True)
    rows = list(wb[sheet].iter_rows(values_only=True))
    underlying = _num(rows[1][2])
    header = list(rows[3])
    ci, pi = header.index("Call price"), header.index("Put price")  # works for both chain workbooks
    recs = [(_num(r[0]), _num(r[ci]), _num(r[pi])) for r in rows[4:] if r[0] is not None]
    df = pd.DataFrame(recs, columns=["strike", "call", "put"]).set_index("strike")
    return underlying, df


def load_current(path=RAW / "ttf_bloomberg_pull.xlsx") -> dict:
    """The six live prices on the snapshot day plus EURUSD, as {ticker: price}."""
    wb = load_workbook(path, data_only=True, read_only=True)
    rows = list(wb["Current"].iter_rows(values_only=True))
    return {r[0].split()[0]: _num(r[1]) for r in rows[1:] if r[0]}
