"""Option maths: Black-76 price, implied vol, implied probabilities."""
import numpy as np
from scipy.stats import norm  # noqa: F401  (use norm.cdf)
from scipy.optimize import brentq  # noqa: F401  (root finder for implied vol)


def black76(F, K, T, r, sigma, kind="c"):
    """Black-76 price of a European option on a future.

    call = DF * (F*N(d1) - K*N(d2)),  put = DF * (K*N(-d2) - F*N(-d1))
    d1 = (ln(F/K) + 0.5*sigma^2*T) / (sigma*sqrt(T)),  d2 = d1 - sigma*sqrt(T),  DF = exp(-r*T)
    Reference: F=31.074, K=31, T=58/365, r=0.0399, sigma=0.6829 -> call = 3.3759.
    """
    raise NotImplementedError


def implied_vol(price, F, K, T, r, kind="c"):
    """Solve black76(...) = price for sigma with a root finder (brentq).

    Think about: bracket (e.g. 1e-4 .. 5), what to return if the price is below intrinsic value,
    and why deep in-the-money options are poor inputs (tiny time value, noisy vol).
    """
    raise NotImplementedError


def implied_density(strikes, call_prices, r, T):
    """Breeden-Litzenberger: risk-neutral density from a strip of call prices.

    density(K) ~ exp(r*T) * [C(K-h) - 2*C(K) + C(K+h)] / h^2
    Careful: raw prices are noisy; negative densities mean you need to smooth the vol smile first
    (compute implied vols, smooth, re-price on a fine strike grid, THEN take the second difference).
    """
    raise NotImplementedError
