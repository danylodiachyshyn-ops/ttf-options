"""Spread construction. The design decisions are yours; the hints are below."""
import pandas as pd

from .load import Q1, Q3


def q_average(prices: pd.DataFrame, months: list) -> pd.Series:
    """Average of the given monthly columns for each date.

    DESIGN QUESTION (answer it before coding): after Jan expires (~30 Dec), what should 'Q1'
    mean? A mean over 'whichever contracts are alive' changes composition on expiry days and
    creates artificial jumps. Plot it and see. Options to consider:
      (a) average only while all three months are alive, then stop;
      (b) a fixed single pair, e.g. Mar vs Sep, as the late-winter measure;
      (c) alive-months average, but report the jump days and exclude them from tests.
    Decide, write down why, and implement.
    """
    raise NotImplementedError


def spread_eur_mwh(winter: pd.DataFrame) -> pd.Series:
    """Daily Q1 minus Q3 in EUR/MWh for one winter DataFrame from load_winters()."""
    raise NotImplementedError
