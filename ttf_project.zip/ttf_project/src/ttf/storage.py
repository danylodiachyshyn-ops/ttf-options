"""EU gas storage from GIE AGSI+ (free). Needs an API key from agsi.gie.eu (register, then My Account).

Do NOT paste the key into code. Put it in an environment variable AGSI_API_KEY (PyCharm: Run > Edit
Configurations > Environment variables).

Read the API documentation on agsi.gie.eu first (link on the site: "API Documentation") for the exact
endpoint, parameters (country/type, date range, paging) and the field names. Alternative with no API:
use the CSV export on the website and save it to data/external/agsi_eu.csv.
"""
import os

import pandas as pd


def load_storage_csv(path="data/external/agsi_eu.csv") -> pd.Series:
    """Return daily EU storage fill in percent as a Series indexed by date.

    TODO: read the file, pick the date and 'full' (%) columns, parse dates, sort, return float Series.
    """
    raise NotImplementedError


def fetch_storage_api(start: str, end: str) -> pd.DataFrame:
    """Optional: download from the API using requests and os.environ['AGSI_API_KEY']."""
    key = os.environ.get("AGSI_API_KEY")
    if not key:
        raise RuntimeError("Set AGSI_API_KEY first")
    raise NotImplementedError
