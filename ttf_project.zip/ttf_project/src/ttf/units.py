"""Unit conversion. Your first function."""

MMBTU_PER_MWH = 3.412  # 1 MWh = 3.412 MMBtu


def usd_mmbtu_to_eur_mwh(price_usd_mmbtu, eurusd):
    """Convert USD/MMBtu to EUR/MWh.

    Hint: worked out together earlier: 31.074 USD/MMBtu at EURUSD 1.1206 is about 94.6 EUR/MWh.
    Works on floats AND on pandas Series (so you can convert a whole column at once).
    """
    raise NotImplementedError
